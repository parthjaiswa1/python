import turtle

t = turtle.Turtle()
turtle.bgcolor("lightgreen")
t.dot(20)
t.goto(100, 0)
t.dot(20)
t.goto(200, 0)
t.dot(20)
