with open('voters_list.txt','a+') as f:
	f.write("New voters info\n")
	f.seek(5)
	data=f.read()
	print(data)
