grade = int(input("Enter your grade."))

if grade >= 98:
    print("A+")
elif grade >=93:
    print("A")
elif grade >= 90:
    print("A-")
elif grade >= 88:
    print("B+")
elif grade >= 83:
    print("B")
elif grade >= 80:
    print("B-")
elif grade >= 78:
    print("C+")
elif grade >= 73:
    print("C")
elif grade >= 70:
    print("C-")
elif grade >= 68:
    print("D+")
elif grade >= 63:
    print("D")
elif grade >= 60:
    print("D-")
elif grade < 60:
    print("F")
    
