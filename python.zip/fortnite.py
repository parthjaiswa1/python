age = int(input("Enter your age."))

if (age > 12) and (age < 18):
    print("You are allowed to play fortnite")
else:
    print("Ask parent permission.")
