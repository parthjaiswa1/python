import random
import turtle
import math
import pygame

snake = turtle.Turtle()
snake.screen.bgcolor("blue")
snake.shape("square")
snake.screen.listen()
snake.penup()

tycord=0
txcord=0


tail=[]
beforetail=[]
xcor_tail = []
ycor_tail = []

for i in range(1,100):
   beforetail.append(turtle.Turtle())
for bt in beforetail:
   bt.hideturtle()


def up():
   if snake.heading() == 270:
      heading = 270
      return heading
   snake.setheading(90)


def down():
   if snake.heading() == 90:
      heading = 90
      return heading
   snake.setheading(270)


def left():
   if snake.heading() == 0:
      heading = 0
      return heading
   snake.setheading(180)


def right():
   if snake.heading() == 180:
      heading = 180
      return heading
   snake.setheading(0)

food = turtle.Turtle()
food.shape('circle')
food.penup()
food.color('red')
food.shapesize(1,1)
def make_food():

   food.hideturtle()
   food.goto(random.randint(-460,460),random.randint(-380,390))
   food.showturtle()

make_food()

score= turtle.Turtle()
score.hideturtle()
score_cntr = 0
score.speed(0)
score.color("white")
score.penup()
score.goto(-350,350)

fontsize = 18
Font = ('Arial', fontsize, 'normal')

score.write("score:" + str(score_cntr) , font=Font)
score.goto(270,350)
score.write("High score:350" , font=Font)


def is_Snake_close_to_food():
   distance = math.sqrt(((food.ycor() - snake.ycor())**2 + (food.xcor() - snake.xcor())**2))
   if distance < 20:
      pygame.mixer.init()
      pygame.mixer.music.load("apple_bite.wav")
      pygame.mixer.music.play()
      return True
   elif distance > 20:
      return False


def increment_score(score_cntr):
   score.clear()
   score.goto(-350,350)
   score.write("score:" + str(score_cntr) , font=Font)

   score.goto(270,350)
   score.write("High score:350" , font=Font)
   return ""

def game_over():
   pygame.mixer.init()
   pygame.mixer.music.load("Explosion+1.wav")
   pygame.mixer.music.play()
   g = turtle.Turtle()
   g.hideturtle()
   z = 0
   while z == 0:
      for game_over_size in range(10, 101, 10):
         g.write("GAME OVER", align = "center" , font = ("Arial"  , game_over_size, "normal"))
         if game_over_size == 100:
            while z == 0:
               snake.forward(0)
         else:
            g.clear()
         

tail.append(snake)


snake.screen.onkey(up, "Up")
snake.screen.onkey(down, "Down")
snake.screen.onkey(left, "Left")
snake.screen.onkey(right, "Right")

def collision():
   length_xcor_tail = len(xcor_tail)
   length_ycor_tail = len(ycor_tail)
   if length_xcor_tail == 0:
      return ""
   if length_xcor_tail == 1:
      return ""
   for x_and_y_coordinate in range(1, length_xcor_tail - 1):
        z = 0
        snake_pos1 = snake.xcor()
        snake_pos2 = snake.ycor()
        
        xcoordinate1 = int(xcor_tail[x_and_y_coordinate])
        ycoordinate2 = int(ycor_tail[x_and_y_coordinate])
        distance = math.sqrt(((ycoordinate2 - snake_pos2)**2 + (xcoordinate1 - snake_pos1)**2))
        if distance <= 0.3:
           game_over()
      

while snake.ycor()<=390 and snake.ycor()>=-380 and snake.xcor()<=460 and snake.xcor()>=-460:
   snakeycord=snake.ycor()
   snakexcord=snake.xcor()
   snake.forward(10)
   snake.speed(0)
   collision()
   counter = 0
   for index in range(1,len(tail)-1):
      tailxcor = tail[index].xcor()
      tailycor = tail[index].ycor()
      xcor_tail.append(tailxcor)
      ycor_tail.append(tailycor)
      newsnakexcord=tail[index].xcor()
      newsnakeycord=tail[index].ycor()
      tail[index].goto(snakexcord,snakeycord)
      snakexcord=newsnakexcord
      snakeycord=newsnakeycord
   

   if is_Snake_close_to_food() is True:
      make_food()
      score_cntr = score_cntr + 10
      increment_score(score_cntr)
     
      snakeycord=snake.ycor()
      snakexcord=snake.xcor()
      snake.forward(10)
     
      realscore=int((score_cntr/10)-1)
     
      tail.append(beforetail[realscore])
     
      tail[realscore].speed(0)
      tail[realscore].hideturtle()
      tail[realscore].shape('square')
      tail[realscore].color("black")
      tail[realscore].penup()
      tail[realscore].showturtle()
     
      for index in range(1,len(tail)-1):
     
         newsnakexcord=tail[index].xcor()
         newsnakeycord=tail[index].ycor()
         tail[index].goto(snakexcord,snakeycord)
         snakexcord=newsnakexcord
         snakeycord=newsnakeycord

      
     
   else:
         continue



game_over()
