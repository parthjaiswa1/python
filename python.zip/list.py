list = [4, 12, 12, 10, 5, 2, 12, 29, 64, 33, 33, 88,12,44,12,12,66]
CurrentPositionNumber = 0
flag = 0
AllpositionNumbers=""
findnumber = int(input("Enter a number."))

for x in list:
    CurrentPositionNumber = CurrentPositionNumber + 1
    if findnumber == x:
        AllpositionNumbers = AllpositionNumbers + str(CurrentPositionNumber) + ","
        flag = 1
        

if flag == 0:
    print("Your number is not in the list.")
else:
    print("The list of numbers has " + str(findnumber) + " at " + AllpositionNumbers       + " position.")
