colorList = ["Red","Blue","Yellow","Green"]
carList = ["Honda","Audi","BMW","Acura"]

for color in colorList:
    pass
for car in carList:
        print(color, car)
