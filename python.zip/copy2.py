import random
import turtle
import math
import time
t = turtle.Turtle()



t.screen.bgcolor("blue")
t.speed(5)

t.shape("square")

tail=[]

t.penup()

beforetail=[]

for i in range(1,100):
  beforetail.append(turtle.Turtle)


def up():
   if t.heading() == 270:
      heading = 270
      return heading
   t.setheading(90)
   for tl in tail:   
      tl.setheading(90)
   
   
xcord=0
ycord=0

def down():
   if t.heading() == 90:
      heading = 90
      return heading
   t.setheading(270)
   for tl in tail:
      tl.setheading(270)
   


def left():
   if t.heading() == 0:
      heading = 0
      return heading
   t.setheading(180)
   for tl in tail:
      tl.setheading(180)

def right():
   if t.heading() == 180:
      heading = 180
      return heading
   t.setheading(0)
   for tl in tail:
      tl.setheading(0)
     
h = turtle.Turtle()
   
def make_food():
   h.shape('circle')
   x=0
   h.penup()
   h.color('red')
   h.shapesize(1,1)
   h.hideturtle()
   h.goto(random.randint(-460,460),random.randint(-380,390))
   h.showturtle()
   while x==0:
      if t.xcor()==h.xcor and t.ycor()==h.ycor():
           x=x+1
           movement()
      distance = math.sqrt(((h.ycor() - t.ycor())**2 + (h.xcor() - t.xcor())**2))
      if distance <= 20:
         h.hideturtle()
         h.goto(random.randint(-460,460),random.randint(-380,390))
         h.showturtle()
         global cntr
         cntr = cntr + 10
         print(cntr)
         f.clear()
         index = cntr/10 - 1
         int(index)
         tail.append(beforetail[1])
         tail[int(index)].speed(5)
         tail[int(index)].hideturtle()
         tail[int(index)].shape('square')
         tail[int(index)].color("black")
         tail[int(index)].penup()
         tail[int(index)].showturtle()
         if t.heading() == 0:
            xcord=t.xcor() - 15
            ycord=t.ycor()
         if t.heading() == 90:
            xcord=t.xcor()
            ycord=t.ycor() - 15
         if t.heading() == 180:
            xcord=t.xcor() + 15
            ycord=t.ycor()
         if t.heading() == 270:
            xcord=t.xcor()
            ycord=t.ycor() + 15
         t.forward(5)
         t.speed(5)
         for tl in tail:
            tl.goto(xcord,ycord)
         score()
           

     
      if t.ycor()<=390 and t.ycor()>=-380 and t.xcor()<=460 and t.xcor()>=-460:
         xcord=t.xcor()
         ycord=t.ycor()
         t.forward(5)
         t.speed(5)
         for tl in tail:
            tl.goto(xcord,ycord)
           
      else:
         break
   return ""

cntr = 0
distance = math.sqrt(((h.ycor() - t.ycor())**2 + (h.xcor() - t.xcor())**2))
f=turtle.Turtle()
f.color("white")
f.penup()
f.goto(-350,350)
fontsize = 18

Font = ('Arial', fontsize, 'normal')

def score():
   f.write("score:" + str(cntr) , font=Font)
   f.goto(270,350)
   f.write("High score:350", font=Font)
   f.hideturtle()
   f.penup()
   f.goto(-350,350)
   movement()


t.screen.onkey(up, "Up")
t.screen.onkey(down, "Down")
t.screen.onkey(left, "Left")
t.screen.onkey(right, "Right")

t.screen.listen()

def movement():
   while t.ycor()<=390 and t.ycor()>=-380 and t.xcor()<=460 and t.xcor()>=-460:
      t.forward(5)
      t.speed(5)
      for tl in tail:
         tl.goto(xcord,ycord)
        
      make_food()

score()
make_food()
movement()
