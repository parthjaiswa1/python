def findTime(c1, c2, c3, c4, c5):
    red = "R"
    white = "W"
    green = "G"
    blue = "B"
    clocks = [c1, c2, c3, c4, c5]
    colors = [red, white, green, blue]

    for clock in clocks:
        for color in colors:
            if clock == color:
                clock = color

    print(c1)
    print(c2)
    hour = red[1] + blue[1]
    minute = int(green[1]) + int(blue[1])
    minute = minute * 5
    minute = str(minute)
    print(hour + ":" + minute)

c1 = input("enter a color")

c2 = input("enter a color")

c3 = input("enter a color")

c4 = input("enter a color")

c5 = input("enter a color")

findTime(c1, c2, c3, c4, c5)
