import turtle
import random


fs = turtle.Turtle()
fs.screen.bgcolor("black")
fs.shape("square")
fs.color("white")


alien = turtle.Turtle()
alien.hideturtle()
alien.penup()
alien.color("red")
alien.shape("circle")

def right():
    fs.right(90)
    fs.speed(5)
    fs.forward(100)
    return ""

def left():
    fs.left(90)
    fs.speed(5)
    fs.forward(100)
    return ""
    
def stop_movement():
    fs.forward(0)

def alien_movement():
    alien.goto(random.randint(-460, 460), random.randint(389, 390))
    alien.right(90)
    alien.showturtle()
    while True:
        alien.speed(1)
        alien.forward(1)

def shoot():
    shot = turtle.Turtle()
    shot.hideturtle()
    shot.color("green")
    shot.shape("arrow")
    shot.goto(fs.xcor(), fs.ycor())
    shot.showturtle()
    shot.goto(alien.xcor(), alien.ycor())

alien_movement()

fs.screen.listen()

##fs.screen.onkey(right, "Right")
##fs.screen.onkey(left, "Left")
##fs.screen.onkeyrelease(stop_movement, "Right")
##fs.screen.onkeyrelease(stop_movement, "Left")

fs.screen.onscreenclick(shoot, "space")

screen.listen()
