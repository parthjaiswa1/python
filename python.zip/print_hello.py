print("Hello World")
'''Below command prints my name
this is my second line comment
'''
print("My name is Parth")
print("This is my first python class")
