numberstudents = int(input("How many students quiz grades do you want?"))
sum1 = 0

for name in range(1, numberstudents + 1):
    name = input("Enter your name.")
    studentID = int(input("Enter your student ID."))
    countofquizgrades = int(input("Enter how many quiz grades you want."))
    
    for quiz in range(1, countofquizgrades + 1):
        quizgrade = int(input("Enter your quiz grade."))
        sum1 = quizgrade + sum1
    average = sum1/countofquizgrades
    print(name)
    print("The average of " + name + "'s quiz grades is " + str(average))
    sum1 = 0

