import turtle

turtle = turtle.Turtle()
turtle_bg = turtle.screen()

turtle_bg.addshape("letter-x-16.gif")
turtle.shape("letter-x-16.gif")
wn.mainloop()
