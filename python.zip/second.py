print('happy fathers day')

print(7+7)
