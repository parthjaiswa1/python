import myCal

a = 10
b=11

ansAdd = myCal.add(a,b)
ansProduct = myCal.multiply(a,b)
ansDivision = myCal.division(a, b)
ansSubtraction = myCal.subtraction(a, b)

print(ansDivision)
print(ansAdd)
print (ansProduct)
print(ansSubtraction)
