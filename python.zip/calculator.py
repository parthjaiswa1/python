list = [4, 6, 8, 12, 34, 67, 89, 99, 123]
count = 0
count2 = 0
count3 = 0
count4 = 0
newnumber = 0
for x in list:
    leastnumber = x
    break
print("Least number : " + str(leastnumber))
for y in list:
    greatestnumber = y
print("Greatest number : " + str(greatestnumber))
for z in list:
    count = count + 1
    newnumber = newnumber + z
print("Sum of all numbers : " + str(newnumber))
if count%2 == 1:
    quotient = int(count//2)
    medianposition = quotient + 1
    for a in list:
        count2 = count2 + 1
        if count2 == medianposition:
            print("Median number : " + str(a))
if count%2 == 0:
    quotient2 = count//2
    for b in list:
        count3 = count3 + 1
        if count3 == quotient2:
            break
    for c in list:
        count4 = count4 + 1
        if count4 == quotient2 + 1:
            median = b+c
            print("Median number : " + str(median//2))
            break
average = newnumber/count
print("Average number : " + str(average))

    
