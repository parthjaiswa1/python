score = int(input("Enter your exam score."))

if score >= 98:
    print("A+")

elif score >= 93:
    print("A")

elif score >= 90:
    print("A-")

elif score >= 88:
    print("B+")

elif score >= 83:
    print("B")

elif score >= 80:
    print("B-")

elif score >= 78:
    print("C+")

elif score >= 73:
    print("C")

elif score >= 70:
    print("C-")

elif score >= 68:
    print("D+")

elif score >= 65:
    print("D")

else:
    print("You need to retake the exam.")


