number = int(input("Enter a number."))

if number%2 == 0:
    print("Even")
elif number%2 == 1:
    print("Odd")
