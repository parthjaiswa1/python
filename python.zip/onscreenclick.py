import turtle

t = turtle.Turtle()

def draw_circle(x, y):
    t.speed(100)
    t.penup()
    t.goto(x,y)
    t.pendown()
    t.color("red")
    t.dot(20)



t.screen.onscreenclick(draw_circle)
