mylist = ["red", "blue", "orange", "green", "black", "white", "yellow", 800]

print(mylist[2])

print(mylist[1:])

mylist.append("New Item")

print(mylist)

mylist.pop(3)

print(mylist)

second_item = mylist[1]

mylist.remove(second_item)

print(mylist)

mylist.insert(4 , "Inserted Item")

print(mylist)
