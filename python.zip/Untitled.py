number1 = int(input("Enter a number."))
number2 = int(input("Enter a number."))
number3 = int(input("Enter a number."))
list[number1, number2, number3]

for x in list in range(1, 100):
    print(x)
