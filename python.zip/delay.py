
# import package
import turtle
  
# turtle movement with
# normal speed
turtle.forward(100)
  
# slow the speed by 
# turtle delay
turtle.delay(3)
  
# turtle movement
turtle.forward(80)
