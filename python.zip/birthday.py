birthyear = int(input("Enter your birth year."))

age = 2020 - birthyear
print("Your calculated age is " + str(age) + ".")
