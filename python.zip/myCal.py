def add(num1, num2):
    ans = num1 + num2
    return ans

def multiply(num1, num2):
    ans = num1 * num2
    return ans

def division(num1 , num2):
    ans = num2/num1
    return ans

def subtraction(num1, num2):
    ans = num1 - num2
    return ans
