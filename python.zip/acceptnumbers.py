number1 = int(input("Enter a number."))
number2 = int(input("Enter a number."))

print(number1)
print(number2)
