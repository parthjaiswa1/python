import turtle
t=turtle.Turtle()

t.screen.bgcolor("lightgreen")

t.screen.title("My first graphics")


t.color("Red")
t.shape("square")
t.shapesize(1,1)

t.hideturtle()
t.penup()
t.goto(100,100)

t.pendown()
t.circle(100,270)
t.goto(100,100)

t.penup()
t.home()
t.showturtle()
t.screen.exitonclick()
