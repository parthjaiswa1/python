Python 3.5.1 (v3.5.1:37a07cee5969, Dec  5 2015, 21:12:44) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> WARNING: The version of Tcl/Tk (8.5.9) in use may be unstable.
Visit http://www.python.org/download/mac/tcltk/ for current information.

>>> 
>>> print("hello world")
hello world
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
hello world
python is awesome!
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
hello
world
python is awesome!
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
hello
world
python is awesome!
hello 
world
>>> print("hello world!)
      
SyntaxError: EOL while scanning string literal
>>> name = input("What is your name?")
What is your name?
>>> print(name = input("What is your name?")




      ff
      
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 

>>> 

>>> 

>>> 
>>> 
>>> 
>>> 
>>> 
>>> name = input("What is your name?")
What is your name?parth
>>> print("Hello," name)
SyntaxError: invalid syntax
>>> print("Hello,", name)
Hello, parth
>>> my_box = student
Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    my_box = student
NameError: name 'student' is not defined
>>> my_box = "student"
>>> my_box = "teacher"
>>> print("my_box")
my_box
>>> print(my_box)
teacher
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
please enter your friend's age:12
Traceback (most recent call last):
  File "/Users/Parth/python/myfirstprogram.py", line 2, in <module>
    print("your friend is". box2, "years old")
AttributeError: 'str' object has no attribute 'box2'
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
please enter your friend's age:"12"
Traceback (most recent call last):
  File "/Users/Parth/python/myfirstprogram.py", line 2, in <module>
    print("your friend is". box2, "years old")
AttributeError: 'str' object has no attribute 'box2'
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
please enter your friend's age:12
your friend is 12 years old
the combined age is:
Traceback (most recent call last):
  File "/Users/Parth/python/myfirstprogram.py", line 5, in <module>
    print(box1+box2)
NameError: name 'box1' is not defined
>>> 
=============== RESTART: /Users/Parth/python/myfirstprogram.py ===============
please enter your age:12
you are 12 years old
please enter your friend's age:11
your friend is 11 years old
the combined age is:
1211
>>> 
