list = [2, 7, 5, 28, 93, 24, 10, 52, 11, 35]
isfound = 0
count = 0
count2 = 0
for x in list:
    remainder = x%5
    count2 = count2 + 1
    if(remainder==0):
        print(x)
        isfound = 1
        count = count+1
        
        

if(isfound == 0):
    print("No number is divisible by 5.")
if(isfound == 1):
    print("There is " + str(count2)  + " numbers.")
    print("There is " + str(count)  + " number(s) divisible by 5.")
    count3 = count2-count
    print("There is " + str(count3)  + " number(s) not divisible by 5.")
