numberoflines = int(input("Enter a number."))
z = ""
for x in range(1, numberoflines+1):
    z=""
    for y in range(1, x+1):
        z = z+str(y) + " "
    print (z)
        
