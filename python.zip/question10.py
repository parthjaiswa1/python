Number = int(input("Enter a positive whole number."))

Remainder = Number%2

if(Remainder==0):
    print("Even Number.")
elif(Remainder==1):
    print("Odd Number.")
