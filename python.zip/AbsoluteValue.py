def getAbsoluteValue(number):
    if number > 0:
        return number
    elif number < 0:
        firstcalc = number - number
        secondcalc = firstcalc - number
        return secondcalc
    elif number == 0:
        return number


##############################


num = int(input("Enter a number:"))

output = getAbsoluteValue(num)
print(output)
