numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
index = 9

while index > -1:
    print(numbers[index])
    index = index - 1
