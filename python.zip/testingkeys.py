import turtle

t = turtle.Turtle()

def draw_circle():
    t.goto(10,10)
    t.color("red")
    t.dot(20)

def move_forward():
    t.forward(100)

def go_left():
    if not (t.heading() == 180):
        t.setheading(180)
        t.forward(20)

def write():
    t.goto(-100,100)
    t.write("Hello")
    
t.screen.onkey(draw_circle, 'Up')
t.screen.onkey(move_forward, 'Down')
t.screen.onkey(go_left, 'Left')
t.screen.onkey(draw_circle, 'Right')
t.screen.onkey(write, 'k')


t.screen.listen()

while True:
    t.forward(1)
