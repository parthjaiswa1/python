print('my first program adds two numbers ')
print(2+2)
