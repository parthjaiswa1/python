import pygame
pygame.mixer.init()
pygame.mixer.music.load("wavefilepath.wav")
pygame.mixer.music.play()
