def addTwoNumbers(paraNum1, paraNum2):
    sumResult = paraNum1 + paraNum2
    return sumResult

######################


userNum1 = int(input("Enter number 1:"))
userNum2 = int(input("Enter number 2:"))


outputSum = addTwoNumbers(userNum1, userNum2)
print(outputSum)


outputSum = addTwoNumbers(100, 250)

print(outputSum)

outputSum = addTwoNumbers(1000, 2500)

print(outputSum)
