import pygame
pygame.mixer.init()
pygame.mixer.music.load("Explosion+1.wav")
pygame.mixer.music.play()
