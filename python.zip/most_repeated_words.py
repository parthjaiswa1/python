file_object = open("story.txt" , "r")

word_counter = 0
word2 = ""
length1 = 0
new_word_list = []
repeated_words = []

for file_line in file_object:
    word_list = file_line.split()
    for word in word_list:
       if word != word2:
           new_word_list.append(word)
           
       elif word == word2:
           repeated_words.append(word)
           print(repeated_words)
