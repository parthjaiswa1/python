box1 = input("please enter your age:")
print("you are", box1, "years old")


box2 = input("please enter your friend's age:")
print("your friend is", box2, "years old")
print("the combined age is:")

print(box1+box2)
