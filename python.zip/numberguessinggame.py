import random

a = 10
b=11
#print(dir(random))

randomNumber = random.randrange(1,10)

counter =1
while counter <= 3:
    userNumber = int(input("Guess your number between 1- 10:"))
    if userNumber == randomNumber:
        print("You Won!")
        print("Expected Number was " + str(randomNumber))
        break
    counter = counter + 1

if counter > 3:
        print("You Lost!")
        print("Expected Number was " + str(randomNumber))
