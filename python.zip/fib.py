def fib(fib1, fib2):
    counter = 0
    while counter < places - 3:
        if counter == 0:
            print("1")
            print("1")
            print("2")
        sum1 = fib1 + fib2
        fib1 = fib2
        fib2 = sum1
        counter = counter + 1
        print(sum1)

fib1 = 1
fib2 = 2
places = 10
fib(fib1, fib2)
