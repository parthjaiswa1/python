file_object = open("story.txt" , "r")

word_counter = 0
word = ""
length1 = 0
punctuation_list = ["?" , "!" ,"." , "," , '"' , "'" , ")" , "("]

for file_line in file_object:
   word_list = file_line.split()
   for word in word_list:
       length2 = len(word)
       punc_counter = 1
       for punctuation in punctuation_list:
          if word[length2 - punc_counter] == punctuation:
             punc_counter = punc_counter + 1
          else:
             continue
       if punc_counter != 1:
          length2 = length2 - punc_counter

       if length2 > length1:
          length1 = length2
          biggest_word = word
       else:
          continue

print(biggest_word[0:length1])
print(length1)
