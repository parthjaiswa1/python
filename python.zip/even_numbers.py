number = 2

while number < 21:
    if number%2 == 0:
        print(number)

    number = number + 1
