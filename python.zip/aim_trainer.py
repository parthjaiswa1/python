import turtle
import random

t = turtle.Turtle()
t.screen.bgcolor("black")
t.color("white")
t.shape("circle")
t.shapesize(2, 2)
t.speed(0)
t.penup()

r = turtle.Turtle()
r.color("red")
r.shape("circle")
r.shapesize(0.3, 0.3)
r.speed(0)
r.penup()
r.hideturtle()

bg = turtle.Screen()

s = turtle.Turtle()
s.hideturtle()
score_counter = 0
s.speed(0)
s.color("green")
s.penup()
s.goto(-250, 350)

t.screen.listen()
while True:

    def new_place(x, y):
       t.hideturtle()
       t.goto(random.randint(-460,460),random.randint(-380,390))
       t.showturtle()

       
    def red_dot(x, y):
        r.goto(x, y)
        r.showturtle()
    t.onclick(new_place)
    bg.onclick(red_dot)
