import turtle

snake = turtle.Turtle()
snake.screen.bgcolor("black")

x = turtle.Turtle()
x.color("orange")
x.hideturtle()
x.penup()
x.forward(100)
x.pendown()
x.showturtle()

line = turtle.Turtle()
line.color("white")
line.hideturtle()
line.penup()
line.goto(125,0)

#bottom horizontal line
line.pensize(25)
line.left(180)
line.pendown()
line.forward(300)

#top horizontal line
line.penup()
line.goto(125, 115)
line.pendown()
line.forward(300)

#right vertical line
line.penup()
line.goto(30, 215)
line.left(90)
line.pendown()
line.forward(300)

#left vertical line
line.penup()
line.goto(-75, 215)
line.pendown()
line.forward(300)

