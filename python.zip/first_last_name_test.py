x=input("what is your first name?")
y=input("what is your last name?")
print(y+" "+x)
