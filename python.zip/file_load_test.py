import time

file_object = open("video_games.txt","r")
file_content = file_object.readline()

print(file_content)

file_object.close()
new_content = "My New Content."

file_object_write = open("video_games.txt","w+")

file_object_write.write(new_content)
file_object_write.flush()
print("sleeping")
time.sleep(20)

file_object_write.seek(0)

file_read = file_object_write.read()
print(file_read)
file_object_write.close()
