number = 1

while number < 21:
    if number%2 == 1:
        print(number)

    number = number + 1
