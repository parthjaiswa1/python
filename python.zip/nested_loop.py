colorList = ["Red","Blue","Green","Yellow"]
carList = ["Honda","Audi","BMW","Acura"]

for color in colorList:
    for car in carList:
        print(color, car)
