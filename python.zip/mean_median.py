list = [3, 5, 10, 16, 17, 23, 25, 26, 32, 34, 38]

for x in list:
    leastnumber = x
    break

for y in list:
    greatestnumber = y

print(leastnumber)
print(greatestnumber)
