import turtle
import random
t=turtle.Turtle()

t.screen.bgcolor("lightgreen")

t.screen.title("My first grpahics")

t.color("Red")
t.shape("turtle")
t.shapesize(1,1)

#t.hideturtle()
t.penup()
t.goto(100,100)

t.pendown()
t.circle(100)

t.penup()
t.goto(100,200)
t.dot(5)
t.goto(110,200)
t.write("Center")

#t.stamp()
t.penup()
t.home()
t.pendown()
t.write("Origin")

f=turtle.Turtle()
f.color("blue")
f.pensize(5)

t.penup()
for i in range(10):
    x = random.randint(10,100)
    y = random.randint(10,100)
    
    f.goto(x,y)
    f.pendown()
    f.dot(5)
    f.penup()

f.clear()
f.pendown()
f.speed(5)
for i in range(100):
    randomlength = random.randint(10,30)
    randomangle = random.randint(1,360)
    randomcolor = random.choices(["red","green","yellow","orange","purple"])
    f.color(randomcolor)
    f.forward(randomlength)
    f.left(randomangle)

t.screen.exitonclick()
