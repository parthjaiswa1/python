print("Hello", end = "\n")
print("World")
