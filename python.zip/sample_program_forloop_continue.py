

gradeList = [55, 98, 86, 44, 77, 109, 23, 90, 60, 45, 99, 78]

maximum = gradeList[0]
minimum = gradeList[0]
sum = 0
count =0
passinggrades = 0
failinggrades = 0

for grade in gradeList:
   
    if grade > 100:
        print("Encountered value greater than 100")
        continue

    print("I am using grade: " + str(grade))
    sum = sum + grade
    count = count + 1
    if grade >= 60:
        passinggrades = passinggrades + 1
    elif grade < 60:
        failinggrades = failinggrades + 1
    if grade > maximum:
        maximum = grade
    if grade < minimum:
        minimum = grade

average = sum//count
print("The average grade is " + str(average))
