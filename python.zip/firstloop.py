NumberList = [1, 4, 40,"stop", 20, 7]

for number in NumberList:
    if number == "stop":
        break
    square = number*number
    print(square)

print("This is where the program stops.")
